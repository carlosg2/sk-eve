---
tenant: icf
description: >
  Use when the user asks sobre el sistema MRP/Forecast de Campo Fresco
  (MRPCF5000) de la empresa ICF: ¿tenemos materia prima suficiente?, stock de
  seguridad o inventario mínimo/máximo, cobertura de inventario, plan de
  producción vs. disponible, estado del MRP, faltantes de producción,
  cumplimiento de producción, "¿cuánto frijol/concentrado tenemos?", "¿qué nos
  falta para producir?". Analista MRP CF: combina los snapshots del proceso
  (ExplocionMatCF, ForecastPlanProduccion) con catálogos (UV_QV_PPTOCOMPRA,
  ArtDisponibleDesc, ArtMaterial) sin ejecutar stored procedures.
---

# Skill: MRP CF Analyst (Campo Fresco / ICF)

> **Este skill es SOLO procedural.** El schema de entidades vive en el Company
> Twin: [mrp-explosion.md](`mrp-explosion`),
> [mrp-plan-produccion.md](`mrp-plan-produccion`),
> [mrp-centros-estaciones.md](`mrp-centros-estaciones`),
> [mrp-vaca.md](`mrp-vaca`)
> y del sistema (`ArtDisponible`, `Art`, `Alm`, `Prod`, `ProdD`).

Conexión MCP: **`intelisis-dab`** (remoto). Tools: `read_records`,
`aggregate_records`. `Usuario` fijo del módulo FC: **`"MASERP"`** (los snapshots
de este módulo son por usuario ERP que corrió el proceso, no por quien chatea).

## Contract

Dada una pregunta de negocio sobre producción, inventario o materia prima:

1. Identifica qué entidades del módulo MRP/FC responden la pregunta.
2. Construye la consulta mínima y suficiente (DAB/OData, NO SQL).
3. Ejecútala contra el MCP de la empresa ICF.
4. Interpreta el resultado en términos de negocio (no jerga técnica).
5. Señala explícitamente si los datos son de un ejercicio anterior al actual.

**Garantías:**
- Nunca ejecutar DML (`create_record`/`update_record`/`execute_entity`) — solo lectura.
- ⚠️ `UtLogEjcProMrp` NO existe en el MCP ICF (EntityNotFound) — no llamarla. Para semanas/fechas usar `DIM_TIEMPO_SEMANA` (campos `Anio`/`MES`/`SEMANA`/`FECHAINICIO`/`FECHAFIN`) o `CalendarioFC`.
- Advertir cuando `CalendarioFC` no cubre el año actual.
- Calificar los datos por ejercicio y `Usuario` de sesión.

## Modelo de datos clave

```
ForecastPlanProduccion — Plan de producción semanal consolidado (vista calculada).
                         Campos :
                         EJERCICIO, PERIODO, SEMANA, SITUACION, CENTROTRABAJO,
                         ARTICULO, DESCRIPCION, PORPRODUCIR, KILOS, FAMILIA.
                         Para "qué se va a producir esta semana" empezar AQUÍ.
ResumenPlaneacionCF   — GRID MAESTRO de planeación: UNA fila por artículo con
                         Articulo, Descripcion, FamiliaCF, VariedadCF y los 54
                         pares S<n>/P<n> (semana/producir). Verificado en vivo
                         Es la fuente
                         para "artículos de la familia X del sistema FC" y
                         agregados por FamiliaCF (ver mrp-concentrado).
ExplocionMatCF        — Explosión de materiales vs. disponible (snapshot de sesión)
ArtDisponibleDesc     — Inventario actual por almacén y empresa (vista ENRIQUECIDA
                        con Descripcion1/Unidad; usar SIEMPRE esta, no ArtDisponible)
ArtMaterial           — Lista de materiales (BOM): artículo → materiales
CalendarioFC          — Calendario de semanas por usuario/año (Ano, Semana,
                        FechaD, FechaA). Alternativa: `DIM_TIEMPO_SEMANA`
                        (campos `Anio`/`MES`/`SEMANA`).
UV_QV_PPTOCOMPRA      — Stock mínimo/máximo y máx. de compra por artículo/familia (materia prima)
CentroFCTemp / EstacionTFCTemp — Centros/estaciones y capacidades (sesión de usuario)
Prod / ProdD          — Producción real transaccional (del sistema)
VentaTCalc            — Ventas reales para comparar vs. forecast
```

### Schema — `UV_QV_PPTOCOMPRA` (vista de presupuesto de compra)

Columnas :
`NIVELAGRUPAMIENTO` (ARTICULO/FAMILIA), `TIPO`, `FAMILIA`, `LINEA`, `ARTICULO`,
`DESCRIPCION`, `TIPOCATALOGO`, `INVMINIMOKG`, `INVMAXIMOKG`, `MAXCOMPRAKG`.

`INVMINIMOKG`/`INVMAXIMOKG` son el **stock de seguridad** (mínimo/máximo en Kg);
`MAXCOMPRAKG` el máximo de compra en Kg. Pueden venir `null` para artículos sin
parámetro configurado — no asumir 0.

## Fase 1 — Clasificar la pregunta

| Tipo de pregunta | Entidades principales |
|---|---|
| Stock de seguridad / min-máx | `UV_QV_PPTOCOMPRA`, `Art` |
| Inventario disponible | `ArtDisponibleDesc`, `Art`, `Alm` |
| Cobertura de materia prima (30 días) | `ExplocionMatCF`, `ArtMaterial` |
| Plan de producción | `ForecastPlanProduccion` |
| Cumplimiento real vs. plan | `ForecastPlanProduccion`, `Prod`, `ProdD` |
| Capacidad de centros | `CentroFCTemp`, `EstacionTFCTemp` |
| Forecast vs. ventas | `ForecastPlanProduccion`, `VentaTCalc` |

## Fase 2 — Construir la consulta (convenciones DAB)

1. Parámetros sin `$`: `filter`, `select`, `first`, `orderby`.
2. Fechas sin comillas: `Fecha ge 2026-01-01`; strings con comillas simples:
   `Estatus eq 'ALTA'`. `in` NO soportado → encadenar `or`.
3. **El casing de los campos es POR VISTA** :
   `ForecastPlanProduccion` y `UV_QV_PPTOCOMPRA` son **UPPERCASE** (`SEMANA`,
   `EJERCICIO`, `PORPRODUCIR`); `CalendarioFC`, `ResumenPlaneacionCF` y
   `ExplocionMatCF` son **camelCase** (`Ano`, `Semana`, `FechaD`, `FamiliaCF`,
   `Producir`, `Kg`). Ante duda, `read_records(<Entidad>, first: 1)` sin
   `select` o el mensaje del error del filter ("Could not find a property
   named X") revela el casing correcto.
4. Filtrar por `Usuario eq 'MASERP'` en las tablas de trabajo que lo tienen
   (`ResumenPlaneacionCF`, `ExplocionMatCF`, `CalendarioFC`, `CentroFCTemp`,
   `EstacionTFCTemp`, `BalanceFC`, `WebInicio`, `Arribos12`) y por
   `Ejercicio`/`Periodo` cuando aplique — no traer corridas de otros
   usuarios. ⚠️ `ForecastPlanProduccion` es una vista consolidada **SIN
   `Usuario`** : filtrarla por Usuario da `BadRequest`; filtrar
   por `EJERCICIO`/`SEMANA`/`SITUACION`.
5. Para inventario: `Almacen eq '<ALM>'` (política de la empresa) y `Disponible gt 0`.
6. `UtLogEjcProMrp` NO existe en el MCP ICF — no intentar verificar la corrida
   con ella; usar los snapshots directamente y advertir si parecen vacíos.
7. **NUNCA llamar `describe_entities`**: el schema vive en el Company Twin y
   este skill (fuente única). No está disponible como tool del agente.
8. **No duplicar llamadas**: si ya consultaste `X` con el mismo `filter`/`select`
   en este turno, reutiliza el resultado; no repitas el tool call.
9. **No leer vistas masivas**: nunca `read_records` con `first` alto sobre
   `ExplocionMatCF`/`ForecastPlanProduccion` (re-envía ~60k chars por step).
   Usar `aggregate_records` (groupby) o `buscar_registro` (LIKE en servidor).
10. Si un `read_records` con `select` falla , usar
   `read_records(<Entidad>, first: 1)` sin `select` para descubrir columnas reales.

### Consultas base reutilizables

- **Q1 — Stock de seguridad por familia/artículo**
```
read_records(UV_QV_PPTOCOMPRA,
  filter: "NIVELAGRUPAMIENTO eq 'ARTICULO' and FAMILIA eq '<F>'",
  select: "FAMILIA,LINEA,ARTICULO,DESCRIPCION,INVMINIMOKG,INVMAXIMOKG,MAXCOMPRAKG")
```
Para el nivel familia, filtrar `NIVELAGRUPAMIENTO eq 'FAMILIA'`.

- **Q1b — Stock de seguridad AGRUPADO por familia (resumen)**
Cuando el usuario pide el resumen "por familia" o "agrupado por familia", **NO**
leas la vista completa (`read_records` con `first` alto devuelve ~60k chars que se
re-envían en cada step e inflan el contexto). Usar `aggregate_records` con
`groupby` directamente:
```
aggregate_records(UV_QV_PPTOCOMPRA,
  filter: "INVMINIMOKG gt 0",
  groupby: ["FAMILIA"], function: "sum", field: "INVMINIMOKG")
aggregate_records(UV_QV_PPTOCOMPRA,
  filter: "INVMINIMOKG gt 0",
  groupby: ["FAMILIA"], function: "sum", field: "INVMAXIMOKG")
```
Combinar los dos resultados por `FAMILIA`. Si hace falta el detalle por artículo
de UNA familia, recién ahí usar Q1 con filtro `FAMILIA eq '<F>'`. Limitar
siempre `select`/`filter`; nunca traer la vista entera.

- **Q2 — Inventario de materia prima (disponible por artículo)**
⚠️ Usar SIEMPRE la vista **`ArtDisponibleDesc`** (17 campos, incluye `Descripcion1`
y `Unidad`). La vista mínima `ArtDisponible` (6 campos) NO tiene
`Descripcion1`/`Unidad`/`Tipo` — pedirlos en su `select` falla con
`BadRequest: Invalid field to be returned requested: Descripcion1`.
```
read_records(ArtDisponibleDesc, filter: "Almacen eq '<ALM>' and Disponible gt 0",
  select: "Articulo,Descripcion1,Disponible,Unidad", orderby: ["Disponible desc"], first: 50)
```
Para totales numéricos puros (agregaciones) sí se puede usar `ArtDisponible`.

- **Q3 — Cobertura de materia prima (explosión)**
```
read_records(ExplocionMatCF, filter: "Usuario eq 'MASERP'",
  select: "Articulo,ArticuloPadre,ArticuloHijo,Total,Faltante,Stock,Producir,AlcanceDias")
```
Si `ExplocionMatCF` viene vacío o desactualizado, armar manualmente cruzando
`ArtMaterial` (BOM) × `ArtDisponible` — ver el skill `gap-abasto` para ese patrón.
Para "30 días" aproximar: `(4.3 / semanas_totales_del_plan) × plan_total` y
declarar la aproximación.

- **Q4 — Plan de producción por familia (piezas y kg)**
```
aggregate_records(ForecastPlanProduccion,
  filter: "EJERCICIO eq <AÑO> and SEMANA eq <N> and SITUACION eq 'Autorizado'",
  groupby: ["FAMILIA"], function: "sum", field: "PORPRODUCIR")
aggregate_records(ForecastPlanProduccion,
  filter: "EJERCICIO eq <AÑO> and SEMANA eq <N> and SITUACION eq 'Autorizado'",
  groupby: ["FAMILIA"], function: "sum", field: "KILOS")
```
Si `aggregate_records` no soporta dos `sum` en una llamada, ejecutarlas por
separado y combinar por `FAMILIA`. Para el total sin desglose, un `sum` sin
`groupby`. ⚠️ Si la semana pedida no tiene plan autorizado, advertirlo y
reportar la semana anterior con plan (verificar `SITUACION eq 'Autorizado'`).
⚠️ `groupby` SIEMPRE en array (`["FAMILIA"]`): con string el DAB lo ignora y
devuelve un solo total. Para la variedad por artículo, `ResumenPlaneacionCF`
SÍ existe (grid maestro por usuario, `Usuario eq 'MASERP'`) — ver Q6.

- **Q5 — Cumplimiento (producido real vs. programado)**
```
aggregate_records(ProdD, filter: "Articulo eq '<A>' and FechaRequerida ge <inicio>T00:00:00Z and FechaRequerida le <fin>T23:59:59Z",
  function: "sum", field: "Cantidad")
```
Cumplimiento % = `SUM(Cantidad real) / Producir programado * 100`; traducir
semana → rango de fechas con `DIM_TIEMPO_SEMANA` o `CalendarioFC` antes de
filtrar.

- **Q6 — Vigencia del calendario (¿cubre hoy?)**
```
read_records(CalendarioFC, filter: "Ano ge 2026 and Usuario eq 'MASERP'",
  select: "Ano,Semana,FechaD,FechaA", orderby: ["Ano desc"], first: 5)
```

## Fase 3 — Interpretar el resultado

Estructura de respuesta estándar:

```
⚠️  [Advertencia de datos si el ejercicio es < al actual o el calendario (DIM_TIEMPO_SEMANA/CalendarioFC) no cubre hoy]

## [Pregunta respondida]

### Resumen ejecutivo
[1-2 oraciones con la respuesta directa]

### Detalle por familia
[tabla con cifras relevantes]

### Conclusión y acción sugerida
[qué hacer con esta información]
```

## Formato de respuesta (obligatorio)

- Tablas en Markdown para datos tabulares.
- Números con separador de miles.
- Kg siempre en Kg (no convertir a toneladas salvo que se pida).
- Semáforo: 🔴 crítico / 🟡 parcial / 🟢 OK.
- Incluir de forma breve las entidades consultadas (no hace falta pegar los
  JSON completos).

## Limitaciones conocidas

- `CalendarioFC` puede no cubrir el año actual; preguntas que requieran semanas
  fuera del rango usan aproximaciones proporcionales y se advierte.
- `ExplocionMatCF`/`ForecastPlanProduccion` son snapshots de la última corrida
  del usuario — pueden estar desactualizados si no se reejecutó el proceso.
  (`UtLogEjcProMrp` NO existe en el MCP ICF; no usarla.)
- `UV_QV_PPTOCOMPRA` es una vista calculada: `INVMINIMOKG`/`INVMAXIMOKG`/
  `MAXCOMPRAKG` pueden ser `null` para artículos sin parámetro.
- El schema de las entidades MRP vive en el Company Twin (mrp-explosion.md,
  mrp-plan-produccion.md) y en este skill; **NO usar `describe_entities`**.
  Si un `select` falla, descubrir el schema con `read_records(first: 1)` antes
  de reintentar.
- El agente es de **solo lectura** sobre este módulo: nunca intentar replicar
  escrituras ni transiciones de estatus.
